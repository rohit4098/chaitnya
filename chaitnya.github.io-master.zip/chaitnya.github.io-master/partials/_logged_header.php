<header class=" container-fluid nav_style mx-auto">
        <div class="row">
            <div class="col-md-12 col-12 mx-auto">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="navbar-brand" href="#home"><img src="img/logo.jpg" alt="" id="logo" class="img-fluid">
                        <h1>Chaitnya</h1>
                        <h2>Public School</h2>
                    </a>
                    <a href="logout.php" class="logout_btn ml-auto">Logout</a>
                </nav>
            </div>
        </div>
    </header>